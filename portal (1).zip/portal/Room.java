package com.portal;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDateTime;

public class Room extends JFrame {
    private JTable roomTable;
    private DefaultTableModel tableModel;
    private JButton addButton, updateButton, deleteButton, refreshButton;
    private JTextField searchField;
    
    // Room properties
    private int roomID;
    private String name;
    private String description;
    private String category;
    private double priceOrValue;
    private String status;
    private LocalDateTime createdAt;
    
    public Room() {
        initializeUI();
        loadRoomData();
    }
    
    public Room(String name, String description, String category, double priceOrValue, String status) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.priceOrValue = priceOrValue;
        this.status = status;
    }
    
    // Getters and Setters
    public int getRoomID() { return roomID; }
    public void setRoomID(int roomID) { this.roomID = roomID; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public double getPriceOrValue() { return priceOrValue; }
    public void setPriceOrValue(double priceOrValue) { this.priceOrValue = priceOrValue; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    private void initializeUI() {
        setTitle("Room Management - Hospitality Portal");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 600);
        setLocationRelativeTo(null);
        
        setLayout(new BorderLayout());
        
        // Header
        JLabel headerLabel = new JLabel("Room Management", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(headerLabel, BorderLayout.NORTH);
        
        // Search panel
        JPanel searchPanel = new JPanel(new FlowLayout());
        searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        
        searchPanel.add(new JLabel("Search by Name or Category:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        
        // Table setup
        String[] columnNames = {"Room ID", "Name", "Description", "Category", "Price", "Status", "Created At"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        roomTable = new JTable(tableModel);
        roomTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane tableScrollPane = new JScrollPane(roomTable);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        addButton = new JButton("Add Room");
        updateButton = new JButton("Update Room");
        deleteButton = new JButton("Delete Room");
        refreshButton = new JButton("Refresh");
        
        // Style buttons
        Color buttonColor = new Color(70, 130, 180);
        addButton.setBackground(buttonColor);
        updateButton.setBackground(buttonColor);
        deleteButton.setBackground(buttonColor);
        refreshButton.setBackground(buttonColor);
        searchButton.setBackground(buttonColor);
        
        addButton.setForeground(Color.WHITE);
        updateButton.setForeground(Color.WHITE);
        deleteButton.setForeground(Color.WHITE);
        refreshButton.setForeground(Color.WHITE);
        searchButton.setForeground(Color.WHITE);
        
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        
        // Add components
        add(searchPanel, BorderLayout.NORTH);
        add(tableScrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Event listeners - Using traditional ActionListener
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showAddRoomDialog();
            }
        });
        
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateSelectedRoom();
            }
        });
        
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteSelectedRoom();
            }
        });
        
        refreshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadRoomData();
            }
        });
        
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                searchRooms();
            }
        });
        
        // Double-click to edit
        roomTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    updateSelectedRoom();
                }
            }
        });
    }
    
    private void showAddRoomDialog() {
        final JDialog dialog = new JDialog(this, "Add New Room", true);
        dialog.setLayout(new GridLayout(0, 2, 10, 10));
        dialog.setSize(400, 400);
        dialog.setLocationRelativeTo(this);
        
        // Create components - declared as final for use in inner classes
        final JTextField nameField = new JTextField();
        final JTextArea descriptionArea = new JTextArea(3, 20);
        final JTextField categoryField = new JTextField();
        final JTextField priceField = new JTextField();
        final JComboBox<String> statusCombo = new JComboBox<String>(new String[]{"Available", "Occupied", "Maintenance", "Cleaning"});
        
        // Add components to dialog
        dialog.add(new JLabel("Room Name:"));
        dialog.add(nameField);
        dialog.add(new JLabel("Description:"));
        dialog.add(new JScrollPane(descriptionArea));
        dialog.add(new JLabel("Category:"));
        dialog.add(categoryField);
        dialog.add(new JLabel("Price:"));
        dialog.add(priceField);
        dialog.add(new JLabel("Status:"));
        dialog.add(statusCombo);
        
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");
        
        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String name = nameField.getText();
                    String description = descriptionArea.getText();
                    String category = categoryField.getText();
                    double price = Double.parseDouble(priceField.getText());
                    String status = (String) statusCombo.getSelectedItem();
                    
                    if (addRoomToDatabase(name, description, category, price, status)) {
                        JOptionPane.showMessageDialog(dialog, "Room added successfully!");
                        dialog.dispose();
                        loadRoomData();
                    } else {
                        JOptionPane.showMessageDialog(dialog, "Failed to add room!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(dialog, "Please enter a valid price number!", "Input Error", JOptionPane.ERROR_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Please check your input fields!", "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        dialog.add(new JLabel());
        dialog.add(buttonPanel);
        dialog.setVisible(true);
    }
    
    private void updateSelectedRoom() {
        int selectedRow = roomTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a room to update");
            return;
        }
        
        final int roomID = (int) tableModel.getValueAt(selectedRow, 0);
        String currentName = tableModel.getValueAt(selectedRow, 1).toString();
        String currentDescription = tableModel.getValueAt(selectedRow, 2).toString();
        String currentCategory = tableModel.getValueAt(selectedRow, 3).toString();
        double currentPrice = Double.parseDouble(tableModel.getValueAt(selectedRow, 4).toString().replace("$", ""));
        String currentStatus = tableModel.getValueAt(selectedRow, 5).toString();
        
        final JDialog dialog = new JDialog(this, "Update Room", true);
        dialog.setLayout(new GridLayout(0, 2, 10, 10));
        dialog.setSize(400, 400);
        dialog.setLocationRelativeTo(this);
        
        // Create components with current values - declared as final
        final JTextField nameField = new JTextField(currentName);
        final JTextArea descriptionArea = new JTextArea(currentDescription, 3, 20);
        final JTextField categoryField = new JTextField(currentCategory);
        final JTextField priceField = new JTextField(String.valueOf(currentPrice));
        final JComboBox<String> statusCombo = new JComboBox<String>(new String[]{"Available", "Occupied", "Maintenance", "Cleaning"});
        statusCombo.setSelectedItem(currentStatus);
        
        dialog.add(new JLabel("Room Name:"));
        dialog.add(nameField);
        dialog.add(new JLabel("Description:"));
        dialog.add(new JScrollPane(descriptionArea));
        dialog.add(new JLabel("Category:"));
        dialog.add(categoryField);
        dialog.add(new JLabel("Price:"));
        dialog.add(priceField);
        dialog.add(new JLabel("Status:"));
        dialog.add(statusCombo);
        
        JButton updateButton = new JButton("Update");
        JButton cancelButton = new JButton("Cancel");
        
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String name = nameField.getText();
                    String description = descriptionArea.getText();
                    String category = categoryField.getText();
                    double price = Double.parseDouble(priceField.getText());
                    String status = (String) statusCombo.getSelectedItem();
                    
                    if (updateRoomInDatabase(roomID, name, description, category, price, status)) {
                        JOptionPane.showMessageDialog(dialog, "Room updated successfully!");
                        dialog.dispose();
                        loadRoomData();
                    } else {
                        JOptionPane.showMessageDialog(dialog, "Failed to update room!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(dialog, "Please enter a valid price number!", "Input Error", JOptionPane.ERROR_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Please check your input fields!", "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(updateButton);
        buttonPanel.add(cancelButton);
        
        dialog.add(new JLabel());
        dialog.add(buttonPanel);
        dialog.setVisible(true);
    }
    
    private void deleteSelectedRoom() {
        int selectedRow = roomTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a room to delete");
            return;
        }
        
        final int roomID = (int) tableModel.getValueAt(selectedRow, 0);
        String roomName = tableModel.getValueAt(selectedRow, 1).toString();
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete room: " + roomName + "?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            if (deleteRoomFromDatabase(roomID)) {
                JOptionPane.showMessageDialog(this, "Room deleted successfully!");
                loadRoomData();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete room!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void searchRooms() {
        String searchText = searchField.getText().trim();
        if (searchText.isEmpty()) {
            loadRoomData();
            return;
        }
        
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "SELECT * FROM Room WHERE Name LIKE ? OR Category LIKE ? OR Description LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "%" + searchText + "%");
            stmt.setString(2, "%" + searchText + "%");
            stmt.setString(3, "%" + searchText + "%");
            
            ResultSet rs = stmt.executeQuery();
            tableModel.setRowCount(0);
            
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("RoomID"),
                    rs.getString("Name"),
                    rs.getString("Description"),
                    rs.getString("Category"),
                    String.format("$%.2f", rs.getDouble("PriceOrValue")),
                    rs.getString("Status"),
                    rs.getTimestamp("CreatedAt")
                };
                tableModel.addRow(row);
            }
            
            rs.close();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error searching rooms: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void loadRoomData() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Room ORDER BY RoomID DESC");
            
            tableModel.setRowCount(0);
            
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("RoomID"),
                    rs.getString("Name"),
                    rs.getString("Description"),
                    rs.getString("Category"),
                    String.format("$%.2f", rs.getDouble("PriceOrValue")),
                    rs.getString("Status"),
                    rs.getTimestamp("CreatedAt")
                };
                tableModel.addRow(row);
            }
            
            rs.close();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading rooms: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Database operations
    private boolean addRoomToDatabase(String name, String description, String category, double price, String status) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "INSERT INTO Room (Name, Description, Category, PriceOrValue, Status) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            stmt.setString(1, name);
            stmt.setString(2, description);
            stmt.setString(3, category);
            stmt.setDouble(4, price);
            stmt.setString(5, status);
            
            int rowsAffected = stmt.executeUpdate();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
            return rowsAffected > 0;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    private boolean updateRoomInDatabase(int roomID, String name, String description, String category, double price, String status) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "UPDATE Room SET Name = ?, Description = ?, Category = ?, PriceOrValue = ?, Status = ? WHERE RoomID = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            stmt.setString(1, name);
            stmt.setString(2, description);
            stmt.setString(3, category);
            stmt.setDouble(4, price);
            stmt.setString(5, status);
            stmt.setInt(6, roomID);
            
            int rowsAffected = stmt.executeUpdate();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
            return rowsAffected > 0;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    private boolean deleteRoomFromDatabase(int roomID) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "DELETE FROM Room WHERE RoomID = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            stmt.setInt(1, roomID);
            int rowsAffected = stmt.executeUpdate();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
            return rowsAffected > 0;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Room().setVisible(true);
            }
        });
    }
}