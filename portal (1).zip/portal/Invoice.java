package com.portal;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDate;

public class Invoice extends JFrame {
    private JTable invoiceTable;
    private DefaultTableModel tableModel;
    private JButton addButton, updateButton, deleteButton, refreshButton;
    private JTextField searchField;
    private JComboBox<String> searchCombo;
    
    public Invoice() {
        initializeUI();
        loadInvoiceData();
    }
    
    private void initializeUI() {
        setTitle("Invoice Management - Hospitality Portal");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1200, 700);
        setLocationRelativeTo(null);
        
        setLayout(new BorderLayout());
        
        // Header
        JLabel headerLabel = new JLabel("Invoice Management", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(headerLabel, BorderLayout.NORTH);
        
        // Search panel
        JPanel searchPanel = new JPanel(new FlowLayout());
        searchField = new JTextField(20);
        searchCombo = new JComboBox<String>(new String[]{"All", "Reference", "Type", "Status"});
        JButton searchButton = new JButton("Search");
        
        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(searchField);
        searchPanel.add(new JLabel("By:"));
        searchPanel.add(searchCombo);
        searchPanel.add(searchButton);
        
        // Table setup
        String[] columnNames = {"Invoice ID", "Amount", "Date", "Type", "Reference", "Status", "Guest ID", "Service ID"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        invoiceTable = new JTable(tableModel);
        invoiceTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        invoiceTable.getTableHeader().setReorderingAllowed(false);
        
        JScrollPane tableScrollPane = new JScrollPane(invoiceTable);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        addButton = new JButton("Add Invoice");
        updateButton = new JButton("Update Invoice");
        deleteButton = new JButton("Delete Invoice");
        refreshButton = new JButton("Refresh");
        
        // Style buttons
        Color buttonColor = new Color(70, 130, 180);
        addButton.setBackground(buttonColor);
        updateButton.setBackground(buttonColor);
        deleteButton.setBackground(buttonColor);
        refreshButton.setBackground(buttonColor);
        searchButton.setBackground(buttonColor);
        
        addButton.setForeground(Color.WHITE);
        updateButton.setForeground(Color.WHITE);
        deleteButton.setForeground(Color.WHITE);
        refreshButton.setForeground(Color.WHITE);
        searchButton.setForeground(Color.WHITE);
        
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        
        // Add components to main frame
        add(searchPanel, BorderLayout.NORTH);
        add(tableScrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Event listeners with traditional ActionListener
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showAddInvoiceDialog();
            }
        });
        
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateSelectedInvoice();
            }
        });
        
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteSelectedInvoice();
            }
        });
        
        refreshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadInvoiceData();
            }
        });
        
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                searchInvoices();
            }
        });
        
        // Double-click to edit
        invoiceTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    updateSelectedInvoice();
                }
            }
        });
    }
    
    private void showAddInvoiceDialog() {
        final JDialog dialog = new JDialog(this, "Add New Invoice", true);
        dialog.setLayout(new GridLayout(0, 2, 10, 10));
        dialog.setSize(400, 350);
        dialog.setLocationRelativeTo(this);
        
        final JTextField amountField = new JTextField();
        final JTextField dateField = new JTextField(LocalDate.now().toString());
        final JTextField typeField = new JTextField();
        final JTextField referenceField = new JTextField();
        final JComboBox<String> statusCombo = new JComboBox<String>(new String[]{"Pending", "Paid", "Cancelled", "Overdue"});
        final JTextField guestIDField = new JTextField();
        final JTextField serviceIDField = new JTextField();
        
        dialog.add(new JLabel("Amount:"));
        dialog.add(amountField);
        dialog.add(new JLabel("Date (YYYY-MM-DD):"));
        dialog.add(dateField);
        dialog.add(new JLabel("Type:"));
        dialog.add(typeField);
        dialog.add(new JLabel("Reference:"));
        dialog.add(referenceField);
        dialog.add(new JLabel("Status:"));
        dialog.add(statusCombo);
        dialog.add(new JLabel("Guest ID:"));
        dialog.add(guestIDField);
        dialog.add(new JLabel("Service ID:"));
        dialog.add(serviceIDField);
        
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");
        
        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double amount = Double.parseDouble(amountField.getText());
                    LocalDate date = LocalDate.parse(dateField.getText());
                    String type = typeField.getText();
                    String reference = referenceField.getText();
                    String status = (String) statusCombo.getSelectedItem();
                    int guestID = Integer.parseInt(guestIDField.getText());
                    int serviceID = Integer.parseInt(serviceIDField.getText());
                    
                    if (addInvoiceToDatabase(amount, date, type, reference, status, guestID, serviceID)) {
                        JOptionPane.showMessageDialog(dialog, "Invoice added successfully!");
                        dialog.dispose();
                        loadInvoiceData();
                    } else {
                        JOptionPane.showMessageDialog(dialog, "Failed to add invoice!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, 
                        "Please check your input:\n- Amount must be a number\n- Date must be in YYYY-MM-DD format\n- IDs must be numbers", 
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        dialog.add(new JLabel());
        dialog.add(buttonPanel);
        dialog.setVisible(true);
    }
    
    private void updateSelectedInvoice() {
        int selectedRow = invoiceTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an invoice to update");
            return;
        }
        
        final int invoiceID = (int) tableModel.getValueAt(selectedRow, 0);
        double currentAmount = Double.parseDouble(tableModel.getValueAt(selectedRow, 1).toString().replace("$", ""));
        String currentDate = tableModel.getValueAt(selectedRow, 2).toString();
        String currentType = tableModel.getValueAt(selectedRow, 3).toString();
        String currentReference = tableModel.getValueAt(selectedRow, 4).toString();
        String currentStatus = tableModel.getValueAt(selectedRow, 5).toString();
        int currentGuestID = (int) tableModel.getValueAt(selectedRow, 6);
        int currentServiceID = (int) tableModel.getValueAt(selectedRow, 7);
        
        final JDialog dialog = new JDialog(this, "Update Invoice", true);
        dialog.setLayout(new GridLayout(0, 2, 10, 10));
        dialog.setSize(400, 350);
        dialog.setLocationRelativeTo(this);
        
        final JTextField amountField = new JTextField(String.valueOf(currentAmount));
        final JTextField dateField = new JTextField(currentDate);
        final JTextField typeField = new JTextField(currentType);
        final JTextField referenceField = new JTextField(currentReference);
        final JComboBox<String> statusCombo = new JComboBox<String>(new String[]{"Pending", "Paid", "Cancelled", "Overdue"});
        statusCombo.setSelectedItem(currentStatus);
        final JTextField guestIDField = new JTextField(String.valueOf(currentGuestID));
        final JTextField serviceIDField = new JTextField(String.valueOf(currentServiceID));
        
        dialog.add(new JLabel("Amount:"));
        dialog.add(amountField);
        dialog.add(new JLabel("Date (YYYY-MM-DD):"));
        dialog.add(dateField);
        dialog.add(new JLabel("Type:"));
        dialog.add(typeField);
        dialog.add(new JLabel("Reference:"));
        dialog.add(referenceField);
        dialog.add(new JLabel("Status:"));
        dialog.add(statusCombo);
        dialog.add(new JLabel("Guest ID:"));
        dialog.add(guestIDField);
        dialog.add(new JLabel("Service ID:"));
        dialog.add(serviceIDField);
        
        JButton updateButton = new JButton("Update");
        JButton cancelButton = new JButton("Cancel");
        
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double amount = Double.parseDouble(amountField.getText());
                    LocalDate date = LocalDate.parse(dateField.getText());
                    String type = typeField.getText();
                    String reference = referenceField.getText();
                    String status = (String) statusCombo.getSelectedItem();
                    int guestID = Integer.parseInt(guestIDField.getText());
                    int serviceID = Integer.parseInt(serviceIDField.getText());
                    
                    if (updateInvoiceInDatabase(invoiceID, amount, date, type, reference, status, guestID, serviceID)) {
                        JOptionPane.showMessageDialog(dialog, "Invoice updated successfully!");
                        dialog.dispose();
                        loadInvoiceData();
                    } else {
                        JOptionPane.showMessageDialog(dialog, "Failed to update invoice!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, 
                        "Please check your input:\n- Amount must be a number\n- Date must be in YYYY-MM-DD format\n- IDs must be numbers", 
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(updateButton);
        buttonPanel.add(cancelButton);
        
        dialog.add(new JLabel());
        dialog.add(buttonPanel);
        dialog.setVisible(true);
    }
    
    private void deleteSelectedInvoice() {
        int selectedRow = invoiceTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an invoice to delete");
            return;
        }
        
        final int invoiceID = (int) tableModel.getValueAt(selectedRow, 0);
        String reference = tableModel.getValueAt(selectedRow, 4).toString();
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete invoice #" + invoiceID + " (" + reference + ")?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            if (deleteInvoiceFromDatabase(invoiceID)) {
                JOptionPane.showMessageDialog(this, "Invoice deleted successfully!");
                loadInvoiceData();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete invoice!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void searchInvoices() {
        String searchText = searchField.getText().trim();
        String searchType = (String) searchCombo.getSelectedItem();
        
        if (searchText.isEmpty()) {
            loadInvoiceData();
            return;
        }
        
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "SELECT * FROM Invoice WHERE ";
            
            switch (searchType) {
                case "Reference":
                    sql += "Reference LIKE ?";
                    break;
                case "Type":
                    sql += "Type LIKE ?";
                    break;
                case "Status":
                    sql += "Status LIKE ?";
                    break;
                default:
                    sql += "(Reference LIKE ? OR Type LIKE ? OR Status LIKE ?)";
                    break;
            }
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            if (searchType.equals("All")) {
                stmt.setString(1, "%" + searchText + "%");
                stmt.setString(2, "%" + searchText + "%");
                stmt.setString(3, "%" + searchText + "%");
            } else {
                stmt.setString(1, "%" + searchText + "%");
            }
            
            ResultSet rs = stmt.executeQuery();
            
            // Clear existing data
            tableModel.setRowCount(0);
            
            // Add search results
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("InvoiceID"),
                    String.format("$%.2f", rs.getDouble("Amount")),
                    rs.getDate("Date").toString(),
                    rs.getString("Type"),
                    rs.getString("Reference"),
                    rs.getString("Status"),
                    rs.getInt("GuestID"),
                    rs.getInt("ServiceID")
                };
                tableModel.addRow(row);
            }
            
            rs.close();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error searching invoices: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void loadInvoiceData() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Invoice ORDER BY InvoiceID DESC");
            
            // Clear existing data
            tableModel.setRowCount(0);
            
            // Add data rows
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("InvoiceID"),
                    String.format("$%.2f", rs.getDouble("Amount")),
                    rs.getDate("Date").toString(),
                    rs.getString("Type"),
                    rs.getString("Reference"),
                    rs.getString("Status"),
                    rs.getInt("GuestID"),
                    rs.getInt("ServiceID")
                };
                tableModel.addRow(row);
            }
            
            // Update summary
            updateSummary();
            
            rs.close();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading invoices: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updateSummary() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            
            // Get total revenue
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT SUM(Amount) as Total FROM Invoice WHERE Status = 'Paid'");
            double totalRevenue = 0;
            if (rs.next()) {
                totalRevenue = rs.getDouble("Total");
            }
            
            // Get pending total
            rs = stmt.executeQuery("SELECT SUM(Amount) as Total FROM Invoice WHERE Status = 'Pending'");
            double pendingTotal = 0;
            if (rs.next()) {
                pendingTotal = rs.getDouble("Total");
            }
            
            // Get total invoices count
            rs = stmt.executeQuery("SELECT COUNT(*) as Total FROM Invoice");
            int totalInvoices = 0;
            if (rs.next()) {
                totalInvoices = rs.getInt("Total");
            }
            
            setTitle("Invoice Management - Total: " + totalInvoices + " | Revenue: $" + 
                    String.format("%.2f", totalRevenue) + " | Pending: $" + 
                    String.format("%.2f", pendingTotal));
            
            rs.close();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    // Database operations
    private boolean addInvoiceToDatabase(double amount, LocalDate date, String type, String reference, 
                                       String status, int guestID, int serviceID) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "INSERT INTO Invoice (Amount, Date, Type, Reference, Status, GuestID, ServiceID) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            stmt.setDouble(1, amount);
            stmt.setDate(2, Date.valueOf(date));
            stmt.setString(3, type);
            stmt.setString(4, reference);
            stmt.setString(5, status);
            stmt.setInt(6, guestID);
            stmt.setInt(7, serviceID);
            
            int rowsAffected = stmt.executeUpdate();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
            return rowsAffected > 0;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    private boolean updateInvoiceInDatabase(int invoiceID, double amount, LocalDate date, String type, 
                                          String reference, String status, int guestID, int serviceID) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "UPDATE Invoice SET Amount = ?, Date = ?, Type = ?, Reference = ?, Status = ?, GuestID = ?, ServiceID = ? WHERE InvoiceID = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            stmt.setDouble(1, amount);
            stmt.setDate(2, Date.valueOf(date));
            stmt.setString(3, type);
            stmt.setString(4, reference);
            stmt.setString(5, status);
            stmt.setInt(6, guestID);
            stmt.setInt(7, serviceID);
            stmt.setInt(8, invoiceID);
            
            int rowsAffected = stmt.executeUpdate();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
            return rowsAffected > 0;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    private boolean deleteInvoiceFromDatabase(int invoiceID) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "DELETE FROM Invoice WHERE InvoiceID = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            stmt.setInt(1, invoiceID);
            int rowsAffected = stmt.executeUpdate();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
            return rowsAffected > 0;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Invoice().setVisible(true);
            }
        });
    }
}