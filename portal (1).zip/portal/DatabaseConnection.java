package com.portal;

import java.sql.*;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/hospitality_portal";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "password";
    
    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC Driver not found", e);
        }
    }
    
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void initializeSampleData() {
        try (Connection conn = getConnection()) {
            // Insert sample guests
            String insertGuest = "INSERT IGNORE INTO Guest (Username, PasswordHash, Email, FullName, Role) VALUES " +
                    "('admin', '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', 'admin@hotel.com', 'System Administrator', 'Admin'), " +
                    "('john_doe', '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', 'john@email.com', 'John Doe', 'Guest'), " +
                    "('jane_smith', '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', 'jane@email.com', 'Jane Smith', 'Guest')";
            
            // Insert sample rooms
            String insertRoom = "INSERT IGNORE INTO Room (Name, Description, Category, PriceOrValue, Status) VALUES " +
                    "('101', 'Standard Room with King Bed', 'Standard', 150.00, 'Available'), " +
                    "('201', 'Deluxe Room with Ocean View', 'Deluxe', 300.00, 'Available'), " +
                    "('301', 'Executive Suite with Jacuzzi', 'Suite', 500.00, 'Occupied')";
            
            // Insert sample services
            String insertService = "INSERT IGNORE INTO Service (Name, Description, Category, PriceOrValue, Status) VALUES " +
                    "('Breakfast Buffet', 'Continental breakfast with variety of options', 'Food', 25.00, 'Active'), " +
                    "('Spa Treatment', 'Full body massage and relaxation', 'Wellness', 80.00, 'Active'), " +
                    "('Room Service', '24/7 in-room dining service', 'Food', 15.00, 'Active')";
            
            // Insert sample staff
            String insertStaff = "INSERT IGNORE INTO Staff (Name, Identifier, Status, Location, Contact, AssignedSince) VALUES " +
                    "('Alice Johnson', 'EMP001', 'Active', 'Reception', 'alice@hotel.com', '2023-01-15'), " +
                    "('Bob Smith', 'EMP002', 'Active', 'Housekeeping', 'bob@hotel.com', '2023-02-20'), " +
                    "('Carol Davis', 'EMP003', 'Active', 'Kitchen', 'carol@hotel.com', '2023-03-10')";
            
            // Insert sample reservations
            String insertReservation = "INSERT IGNORE INTO Reservation (OrderNumber, Date, Status, TotalAmount, PaymentMethod, Notes, GuestID, RoomID) VALUES " +
                    "('RES001', '2024-01-15', 'Confirmed', 450.00, 'Credit Card', 'Early check-in requested', 1, 1), " +
                    "('RES002', '2024-01-20', 'Pending', 300.00, 'Cash', 'Late checkout needed', 2, 2)";
            
            // Insert sample invoices
            String insertInvoice = "INSERT IGNORE INTO Invoice (Amount, Date, Type, Reference, Status, GuestID, ServiceID) VALUES " +
                    "(125.00, '2024-01-16', 'Room Service', 'INV001', 'Paid', 1, 1), " +
                    "(80.00, '2024-01-17', 'Spa Service', 'INV002', 'Pending', 1, 2), " +
                    "(45.50, '2024-01-18', 'Restaurant', 'INV003', 'Paid', 2, 3)";
            
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(insertGuest);
            stmt.executeUpdate(insertRoom);
            stmt.executeUpdate(insertService);
            stmt.executeUpdate(insertStaff);
            stmt.executeUpdate(insertReservation);
            stmt.executeUpdate(insertInvoice);
            
        } catch (SQLException e) {
            System.out.println("Error initializing sample data: " + e.getMessage());
        }
    }
}