package com.portal;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDate;

public class Reservation extends JFrame {
    private JTable reservationTable;
    private DefaultTableModel tableModel;
    private JButton addButton, updateButton, deleteButton, refreshButton;
    private JTextField searchField;
    
    public Reservation() {
        initializeUI();
        loadReservationData();
    }
    
    private void initializeUI() {
        setTitle("Reservation Management - Hospitality Portal");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1200, 600);
        setLocationRelativeTo(null);
        
        setLayout(new BorderLayout());
        
        // Header
        JLabel headerLabel = new JLabel("Reservation Management", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(headerLabel, BorderLayout.NORTH);
        
        // Search panel
        JPanel searchPanel = new JPanel(new FlowLayout());
        searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        
        searchPanel.add(new JLabel("Search by Order Number:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        
        // Table setup
        String[] columnNames = {"Reservation ID", "Order Number", "Date", "Status", "Total Amount", "Payment Method", "Notes", "Guest ID", "Room ID"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        reservationTable = new JTable(tableModel);
        reservationTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane tableScrollPane = new JScrollPane(reservationTable);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        addButton = new JButton("Add Reservation");
        updateButton = new JButton("Update Reservation");
        deleteButton = new JButton("Delete Reservation");
        refreshButton = new JButton("Refresh");
        
        // Style buttons
        Color buttonColor = new Color(70, 130, 180);
        addButton.setBackground(buttonColor);
        updateButton.setBackground(buttonColor);
        deleteButton.setBackground(buttonColor);
        refreshButton.setBackground(buttonColor);
        searchButton.setBackground(buttonColor);
        
        addButton.setForeground(Color.WHITE);
        updateButton.setForeground(Color.WHITE);
        deleteButton.setForeground(Color.WHITE);
        refreshButton.setForeground(Color.WHITE);
        searchButton.setForeground(Color.WHITE);
        
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        
        // Add components
        add(searchPanel, BorderLayout.NORTH);
        add(tableScrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Event listeners with traditional ActionListener
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showAddReservationDialog();
            }
        });
        
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateSelectedReservation();
            }
        });
        
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteSelectedReservation();
            }
        });
        
        refreshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadReservationData();
            }
        });
        
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                searchReservations();
            }
        });
    }
    
    private void showAddReservationDialog() {
        final JDialog dialog = new JDialog(this, "Add New Reservation", true);
        dialog.setLayout(new GridLayout(0, 2, 10, 10));
        dialog.setSize(400, 400);
        dialog.setLocationRelativeTo(this);
        
        final JTextField orderNumberField = new JTextField();
        final JTextField dateField = new JTextField(LocalDate.now().toString());
        final JComboBox<String> statusCombo = new JComboBox<String>(new String[]{"Pending", "Confirmed", "Cancelled", "Completed"});
        final JTextField totalAmountField = new JTextField();
        final JComboBox<String> paymentMethodCombo = new JComboBox<String>(new String[]{"Cash", "Credit Card", "Debit Card", "Bank Transfer"});
        final JTextArea notesArea = new JTextArea(3, 20);
        final JTextField guestIDField = new JTextField();
        final JTextField roomIDField = new JTextField();
        
        dialog.add(new JLabel("Order Number:"));
        dialog.add(orderNumberField);
        dialog.add(new JLabel("Date (YYYY-MM-DD):"));
        dialog.add(dateField);
        dialog.add(new JLabel("Status:"));
        dialog.add(statusCombo);
        dialog.add(new JLabel("Total Amount:"));
        dialog.add(totalAmountField);
        dialog.add(new JLabel("Payment Method:"));
        dialog.add(paymentMethodCombo);
        dialog.add(new JLabel("Notes:"));
        dialog.add(new JScrollPane(notesArea));
        dialog.add(new JLabel("Guest ID:"));
        dialog.add(guestIDField);
        dialog.add(new JLabel("Room ID:"));
        dialog.add(roomIDField);
        
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");
        
        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String orderNumber = orderNumberField.getText();
                    LocalDate date = LocalDate.parse(dateField.getText());
                    String status = (String) statusCombo.getSelectedItem();
                    double totalAmount = Double.parseDouble(totalAmountField.getText());
                    String paymentMethod = (String) paymentMethodCombo.getSelectedItem();
                    String notes = notesArea.getText();
                    int guestID = Integer.parseInt(guestIDField.getText());
                    int roomID = Integer.parseInt(roomIDField.getText());
                    
                    if (addReservationToDatabase(orderNumber, date, status, totalAmount, paymentMethod, notes, guestID, roomID)) {
                        JOptionPane.showMessageDialog(dialog, "Reservation added successfully!");
                        dialog.dispose();
                        loadReservationData();
                    } else {
                        JOptionPane.showMessageDialog(dialog, "Failed to add reservation!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, 
                        "Please check your input:\n- Amount must be a number\n- Date must be in YYYY-MM-DD format\n- IDs must be numbers", 
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        dialog.add(new JLabel());
        dialog.add(buttonPanel);
        dialog.setVisible(true);
    }
    
    private void updateSelectedReservation() {
        int selectedRow = reservationTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a reservation to update");
            return;
        }
        
        final int reservationID = (int) tableModel.getValueAt(selectedRow, 0);
        String currentOrderNumber = tableModel.getValueAt(selectedRow, 1).toString();
        String currentDate = tableModel.getValueAt(selectedRow, 2).toString();
        String currentStatus = tableModel.getValueAt(selectedRow, 3).toString();
        double currentTotalAmount = Double.parseDouble(tableModel.getValueAt(selectedRow, 4).toString().replace("$", ""));
        String currentPaymentMethod = tableModel.getValueAt(selectedRow, 5).toString();
        String currentNotes = tableModel.getValueAt(selectedRow, 6).toString();
        int currentGuestID = (int) tableModel.getValueAt(selectedRow, 7);
        int currentRoomID = (int) tableModel.getValueAt(selectedRow, 8);
        
        final JDialog dialog = new JDialog(this, "Update Reservation", true);
        dialog.setLayout(new GridLayout(0, 2, 10, 10));
        dialog.setSize(400, 400);
        dialog.setLocationRelativeTo(this);
        
        final JTextField orderNumberField = new JTextField(currentOrderNumber);
        final JTextField dateField = new JTextField(currentDate);
        final JComboBox<String> statusCombo = new JComboBox<String>(new String[]{"Pending", "Confirmed", "Cancelled", "Completed"});
        statusCombo.setSelectedItem(currentStatus);
        final JTextField totalAmountField = new JTextField(String.valueOf(currentTotalAmount));
        final JComboBox<String> paymentMethodCombo = new JComboBox<String>(new String[]{"Cash", "Credit Card", "Debit Card", "Bank Transfer"});
        paymentMethodCombo.setSelectedItem(currentPaymentMethod);
        final JTextArea notesArea = new JTextArea(currentNotes, 3, 20);
        final JTextField guestIDField = new JTextField(String.valueOf(currentGuestID));
        final JTextField roomIDField = new JTextField(String.valueOf(currentRoomID));
        
        dialog.add(new JLabel("Order Number:"));
        dialog.add(orderNumberField);
        dialog.add(new JLabel("Date (YYYY-MM-DD):"));
        dialog.add(dateField);
        dialog.add(new JLabel("Status:"));
        dialog.add(statusCombo);
        dialog.add(new JLabel("Total Amount:"));
        dialog.add(totalAmountField);
        dialog.add(new JLabel("Payment Method:"));
        dialog.add(paymentMethodCombo);
        dialog.add(new JLabel("Notes:"));
        dialog.add(new JScrollPane(notesArea));
        dialog.add(new JLabel("Guest ID:"));
        dialog.add(guestIDField);
        dialog.add(new JLabel("Room ID:"));
        dialog.add(roomIDField);
        
        JButton updateButton = new JButton("Update");
        JButton cancelButton = new JButton("Cancel");
        
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String orderNumber = orderNumberField.getText();
                    LocalDate date = LocalDate.parse(dateField.getText());
                    String status = (String) statusCombo.getSelectedItem();
                    double totalAmount = Double.parseDouble(totalAmountField.getText());
                    String paymentMethod = (String) paymentMethodCombo.getSelectedItem();
                    String notes = notesArea.getText();
                    int guestID = Integer.parseInt(guestIDField.getText());
                    int roomID = Integer.parseInt(roomIDField.getText());
                    
                    if (updateReservationInDatabase(reservationID, orderNumber, date, status, totalAmount, paymentMethod, notes, guestID, roomID)) {
                        JOptionPane.showMessageDialog(dialog, "Reservation updated successfully!");
                        dialog.dispose();
                        loadReservationData();
                    } else {
                        JOptionPane.showMessageDialog(dialog, "Failed to update reservation!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, 
                        "Please check your input:\n- Amount must be a number\n- Date must be in YYYY-MM-DD format\n- IDs must be numbers", 
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(updateButton);
        buttonPanel.add(cancelButton);
        
        dialog.add(new JLabel());
        dialog.add(buttonPanel);
        dialog.setVisible(true);
    }
    
    private void deleteSelectedReservation() {
        int selectedRow = reservationTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a reservation to delete");
            return;
        }
        
        final int reservationID = (int) tableModel.getValueAt(selectedRow, 0);
        String orderNumber = tableModel.getValueAt(selectedRow, 1).toString();
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete reservation: " + orderNumber + "?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            if (deleteReservationFromDatabase(reservationID)) {
                JOptionPane.showMessageDialog(this, "Reservation deleted successfully!");
                loadReservationData();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete reservation!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void searchReservations() {
        String searchText = searchField.getText().trim();
        if (searchText.isEmpty()) {
            loadReservationData();
            return;
        }
        
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "SELECT * FROM Reservation WHERE OrderNumber LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "%" + searchText + "%");
            
            ResultSet rs = stmt.executeQuery();
            tableModel.setRowCount(0);
            
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("ReservationID"),
                    rs.getString("OrderNumber"),
                    rs.getDate("Date").toString(),
                    rs.getString("Status"),
                    String.format("$%.2f", rs.getDouble("TotalAmount")),
                    rs.getString("PaymentMethod"),
                    rs.getString("Notes"),
                    rs.getInt("GuestID"),
                    rs.getInt("RoomID")
                };
                tableModel.addRow(row);
            }
            
            rs.close();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error searching reservations: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void loadReservationData() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Reservation ORDER BY ReservationID DESC");
            
            tableModel.setRowCount(0);
            
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("ReservationID"),
                    rs.getString("OrderNumber"),
                    rs.getDate("Date").toString(),
                    rs.getString("Status"),
                    String.format("$%.2f", rs.getDouble("TotalAmount")),
                    rs.getString("PaymentMethod"),
                    rs.getString("Notes"),
                    rs.getInt("GuestID"),
                    rs.getInt("RoomID")
                };
                tableModel.addRow(row);
            }
            
            rs.close();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading reservations: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Database operations
    private boolean addReservationToDatabase(String orderNumber, LocalDate date, String status, 
                                           double totalAmount, String paymentMethod, String notes, 
                                           int guestID, int roomID) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "INSERT INTO Reservation (OrderNumber, Date, Status, TotalAmount, PaymentMethod, Notes, GuestID, RoomID) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            stmt.setString(1, orderNumber);
            stmt.setDate(2, Date.valueOf(date));
            stmt.setString(3, status);
            stmt.setDouble(4, totalAmount);
            stmt.setString(5, paymentMethod);
            stmt.setString(6, notes);
            stmt.setInt(7, guestID);
            stmt.setInt(8, roomID);
            
            int rowsAffected = stmt.executeUpdate();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
            return rowsAffected > 0;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    private boolean updateReservationInDatabase(int reservationID, String orderNumber, LocalDate date, 
                                              String status, double totalAmount, String paymentMethod, 
                                              String notes, int guestID, int roomID) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "UPDATE Reservation SET OrderNumber = ?, Date = ?, Status = ?, TotalAmount = ?, PaymentMethod = ?, Notes = ?, GuestID = ?, RoomID = ? WHERE ReservationID = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            stmt.setString(1, orderNumber);
            stmt.setDate(2, Date.valueOf(date));
            stmt.setString(3, status);
            stmt.setDouble(4, totalAmount);
            stmt.setString(5, paymentMethod);
            stmt.setString(6, notes);
            stmt.setInt(7, guestID);
            stmt.setInt(8, roomID);
            stmt.setInt(9, reservationID);
            
            int rowsAffected = stmt.executeUpdate();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
            return rowsAffected > 0;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    private boolean deleteReservationFromDatabase(int reservationID) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "DELETE FROM Reservation WHERE ReservationID = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            stmt.setInt(1, reservationID);
            int rowsAffected = stmt.executeUpdate();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
            return rowsAffected > 0;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Reservation().setVisible(true);
            }
        });
    }
}