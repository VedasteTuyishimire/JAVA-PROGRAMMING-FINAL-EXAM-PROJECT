package com.portal;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDateTime;

public class Service extends JFrame {
    private JTable serviceTable;
    private DefaultTableModel tableModel;
    private JButton addButton, updateButton, deleteButton, refreshButton;
    private JTextField searchField;
    
    public Service() {
        initializeUI();
        loadServiceData();
    }
    
    private void initializeUI() {
        setTitle("Service Management - Hospitality Portal");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 600);
        setLocationRelativeTo(null);
        
        setLayout(new BorderLayout());
        
        // Header
        JLabel headerLabel = new JLabel("Service Management", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(headerLabel, BorderLayout.NORTH);
        
        // Search panel
        JPanel searchPanel = new JPanel(new FlowLayout());
        searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        
        searchPanel.add(new JLabel("Search by Name or Category:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        
        // Table setup
        String[] columnNames = {"Service ID", "Name", "Description", "Category", "Price", "Status", "Created At"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        serviceTable = new JTable(tableModel);
        serviceTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane tableScrollPane = new JScrollPane(serviceTable);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        addButton = new JButton("Add Service");
        updateButton = new JButton("Update Service");
        deleteButton = new JButton("Delete Service");
        refreshButton = new JButton("Refresh");
        
        // Style buttons
        Color buttonColor = new Color(70, 130, 180);
        addButton.setBackground(buttonColor);
        updateButton.setBackground(buttonColor);
        deleteButton.setBackground(buttonColor);
        refreshButton.setBackground(buttonColor);
        searchButton.setBackground(buttonColor);
        
        addButton.setForeground(Color.WHITE);
        updateButton.setForeground(Color.WHITE);
        deleteButton.setForeground(Color.WHITE);
        refreshButton.setForeground(Color.WHITE);
        searchButton.setForeground(Color.WHITE);
        
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        
        // Add components
        add(searchPanel, BorderLayout.NORTH);
        add(tableScrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Event listeners with traditional ActionListener
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showAddServiceDialog();
            }
        });
        
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateSelectedService();
            }
        });
        
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteSelectedService();
            }
        });
        
        refreshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadServiceData();
            }
        });
        
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                searchServices();
            }
        });
    }
    
    private void showAddServiceDialog() {
        final JDialog dialog = new JDialog(this, "Add New Service", true);
        dialog.setLayout(new GridLayout(0, 2, 10, 10));
        dialog.setSize(400, 350);
        dialog.setLocationRelativeTo(this);
        
        final JTextField nameField = new JTextField();
        final JTextArea descriptionArea = new JTextArea(3, 20);
        final JTextField categoryField = new JTextField();
        final JTextField priceField = new JTextField();
        final JComboBox<String> statusCombo = new JComboBox<String>(new String[]{"Active", "Inactive"});
        
        dialog.add(new JLabel("Service Name:"));
        dialog.add(nameField);
        dialog.add(new JLabel("Description:"));
        dialog.add(new JScrollPane(descriptionArea));
        dialog.add(new JLabel("Category:"));
        dialog.add(categoryField);
        dialog.add(new JLabel("Price:"));
        dialog.add(priceField);
        dialog.add(new JLabel("Status:"));
        dialog.add(statusCombo);
        
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");
        
        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String name = nameField.getText();
                    String description = descriptionArea.getText();
                    String category = categoryField.getText();
                    double price = Double.parseDouble(priceField.getText());
                    String status = (String) statusCombo.getSelectedItem();
                    
                    if (addServiceToDatabase(name, description, category, price, status)) {
                        JOptionPane.showMessageDialog(dialog, "Service added successfully!");
                        dialog.dispose();
                        loadServiceData();
                    } else {
                        JOptionPane.showMessageDialog(dialog, "Failed to add service!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Please check your input!", "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        dialog.add(new JLabel());
        dialog.add(buttonPanel);
        dialog.setVisible(true);
    }
    
    private void updateSelectedService() {
        int selectedRow = serviceTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a service to update");
            return;
        }
        
        final int serviceID = (int) tableModel.getValueAt(selectedRow, 0);
        String currentName = tableModel.getValueAt(selectedRow, 1).toString();
        String currentDescription = tableModel.getValueAt(selectedRow, 2).toString();
        String currentCategory = tableModel.getValueAt(selectedRow, 3).toString();
        double currentPrice = Double.parseDouble(tableModel.getValueAt(selectedRow, 4).toString().replace("$", ""));
        String currentStatus = tableModel.getValueAt(selectedRow, 5).toString();
        
        final JDialog dialog = new JDialog(this, "Update Service", true);
        dialog.setLayout(new GridLayout(0, 2, 10, 10));
        dialog.setSize(400, 350);
        dialog.setLocationRelativeTo(this);
        
        final JTextField nameField = new JTextField(currentName);
        final JTextArea descriptionArea = new JTextArea(currentDescription, 3, 20);
        final JTextField categoryField = new JTextField(currentCategory);
        final JTextField priceField = new JTextField(String.valueOf(currentPrice));
        final JComboBox<String> statusCombo = new JComboBox<String>(new String[]{"Active", "Inactive"});
        statusCombo.setSelectedItem(currentStatus);
        
        dialog.add(new JLabel("Service Name:"));
        dialog.add(nameField);
        dialog.add(new JLabel("Description:"));
        dialog.add(new JScrollPane(descriptionArea));
        dialog.add(new JLabel("Category:"));
        dialog.add(categoryField);
        dialog.add(new JLabel("Price:"));
        dialog.add(priceField);
        dialog.add(new JLabel("Status:"));
        dialog.add(statusCombo);
        
        JButton updateButton = new JButton("Update");
        JButton cancelButton = new JButton("Cancel");
        
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String name = nameField.getText();
                    String description = descriptionArea.getText();
                    String category = categoryField.getText();
                    double price = Double.parseDouble(priceField.getText());
                    String status = (String) statusCombo.getSelectedItem();
                    
                    if (updateServiceInDatabase(serviceID, name, description, category, price, status)) {
                        JOptionPane.showMessageDialog(dialog, "Service updated successfully!");
                        dialog.dispose();
                        loadServiceData();
                    } else {
                        JOptionPane.showMessageDialog(dialog, "Failed to update service!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Please check your input!", "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(updateButton);
        buttonPanel.add(cancelButton);
        
        dialog.add(new JLabel());
        dialog.add(buttonPanel);
        dialog.setVisible(true);
    }
    
    private void deleteSelectedService() {
        int selectedRow = serviceTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a service to delete");
            return;
        }
        
        final int serviceID = (int) tableModel.getValueAt(selectedRow, 0);
        String serviceName = tableModel.getValueAt(selectedRow, 1).toString();
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete service: " + serviceName + "?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            if (deleteServiceFromDatabase(serviceID)) {
                JOptionPane.showMessageDialog(this, "Service deleted successfully!");
                loadServiceData();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete service!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void searchServices() {
        String searchText = searchField.getText().trim();
        if (searchText.isEmpty()) {
            loadServiceData();
            return;
        }
        
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "SELECT * FROM Service WHERE Name LIKE ? OR Category LIKE ? OR Description LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "%" + searchText + "%");
            stmt.setString(2, "%" + searchText + "%");
            stmt.setString(3, "%" + searchText + "%");
            
            ResultSet rs = stmt.executeQuery();
            tableModel.setRowCount(0);
            
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("ServiceID"),
                    rs.getString("Name"),
                    rs.getString("Description"),
                    rs.getString("Category"),
                    String.format("$%.2f", rs.getDouble("PriceOrValue")),
                    rs.getString("Status"),
                    rs.getTimestamp("CreatedAt")
                };
                tableModel.addRow(row);
            }
            
            rs.close();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error searching services: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void loadServiceData() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Service ORDER BY ServiceID DESC");
            
            tableModel.setRowCount(0);
            
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("ServiceID"),
                    rs.getString("Name"),
                    rs.getString("Description"),
                    rs.getString("Category"),
                    String.format("$%.2f", rs.getDouble("PriceOrValue")),
                    rs.getString("Status"),
                    rs.getTimestamp("CreatedAt")
                };
                tableModel.addRow(row);
            }
            
            rs.close();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading services: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Database operations
    private boolean addServiceToDatabase(String name, String description, String category, double price, String status) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "INSERT INTO Service (Name, Description, Category, PriceOrValue, Status) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            stmt.setString(1, name);
            stmt.setString(2, description);
            stmt.setString(3, category);
            stmt.setDouble(4, price);
            stmt.setString(5, status);
            
            int rowsAffected = stmt.executeUpdate();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
            return rowsAffected > 0;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    private boolean updateServiceInDatabase(int serviceID, String name, String description, String category, double price, String status) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "UPDATE Service SET Name = ?, Description = ?, Category = ?, PriceOrValue = ?, Status = ? WHERE ServiceID = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            stmt.setString(1, name);
            stmt.setString(2, description);
            stmt.setString(3, category);
            stmt.setDouble(4, price);
            stmt.setString(5, status);
            stmt.setInt(6, serviceID);
            
            int rowsAffected = stmt.executeUpdate();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
            return rowsAffected > 0;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    private boolean deleteServiceFromDatabase(int serviceID) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "DELETE FROM Service WHERE ServiceID = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            stmt.setInt(1, serviceID);
            int rowsAffected = stmt.executeUpdate();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
            return rowsAffected > 0;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Service().setVisible(true);
            }
        });
    }
}