package com.portal;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainApplication extends JFrame {
    private JButton guestButton, roomButton, reservationButton, serviceButton, invoiceButton, staffButton;
    
    public MainApplication() {
        initializeUI();
    }
    
    private void initializeUI() {
        setTitle("Hospitality Portal Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        
        setLayout(new BorderLayout());
        
        // Header
        JLabel headerLabel = new JLabel("Hospitality Portal Management System", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 28));
        headerLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 30, 0));
        add(headerLabel, BorderLayout.NORTH);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new GridLayout(2, 3, 20, 20));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        
        guestButton = createMenuButton("Guest Management");
        roomButton = createMenuButton("Room Management");
        reservationButton = createMenuButton("Reservation Management");
        serviceButton = createMenuButton("Service Management");
        invoiceButton = createMenuButton("Invoice Management");
        staffButton = createMenuButton("Staff Management");
        
        buttonPanel.add(guestButton);
        buttonPanel.add(roomButton);
        buttonPanel.add(reservationButton);
        buttonPanel.add(serviceButton);
        buttonPanel.add(invoiceButton);
        buttonPanel.add(staffButton);
        
        add(buttonPanel, BorderLayout.CENTER);
        
        // Event listeners with traditional ActionListener
        setupEventListeners();
        
        // Initialize sample data
        DatabaseConnection.initializeSampleData();
    }
    
    private JButton createMenuButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        return button;
    }
    
    private void setupEventListeners() {
        guestButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openManagementPanel("Guest");
            }
        });
        
        roomButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openManagementPanel("Room");
            }
        });
        
        reservationButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openManagementPanel("Reservation");
            }
        });
        
        serviceButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openManagementPanel("Service");
            }
        });
        
        invoiceButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openManagementPanel("Invoice");
            }
        });
        
        staffButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openManagementPanel("Staff");
            }
        });
    }
    
    private void openManagementPanel(String panelName) {
        try {
            switch (panelName) {
                case "Guest":
                    new Guest().setVisible(true);
                    break;
                case "Room":
                    new Room().setVisible(true);
                    break;
                case "Reservation":
                    // Try to create Reservation instance with error handling
                    try {
                        Class<?> reservationClass = Class.forName("Reservation");
                        JFrame reservationFrame = (JFrame) reservationClass.newInstance();
                        reservationFrame.setVisible(true);
                    } catch (ClassNotFoundException ex) {
                        JOptionPane.showMessageDialog(this, 
                            "Reservation class not found. Please check your project setup.", 
                            "Class Not Found", JOptionPane.ERROR_MESSAGE);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, 
                            "Error opening Reservation: " + ex.getMessage(), 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    break;
                case "Service":
                    new Service().setVisible(true);
                    break;
                case "Invoice":
                    new Invoice().setVisible(true);
                    break;
                case "Staff":
                    new Staff().setVisible(true);
                    break;
                default:
                    JOptionPane.showMessageDialog(this, 
                        "Unknown panel: " + panelName, 
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                "Error opening " + panelName + " management: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public static void main(String[] args) {
        // Set look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getLookAndFeel());
        } catch (Exception e) {
            // Continue with default look and feel if system L&F fails
        }
        
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MainApplication().setVisible(true);
            }
        });
    }
}