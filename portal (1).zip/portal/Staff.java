package com.portal;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDate;

public class Staff extends JFrame {
    private JTable staffTable;
    private DefaultTableModel tableModel;
    private JButton addButton, updateButton, deleteButton, refreshButton;
    private JTextField searchField;
    
    public Staff() {
        initializeUI();
        loadStaffData();
    }
    
    private void initializeUI() {
        setTitle("Staff Management - Hospitality Portal");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 600);
        setLocationRelativeTo(null);
        
        setLayout(new BorderLayout());
        
        // Header
        JLabel headerLabel = new JLabel("Staff Management", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(headerLabel, BorderLayout.NORTH);
        
        // Search panel
        JPanel searchPanel = new JPanel(new FlowLayout());
        searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        
        searchPanel.add(new JLabel("Search by Name or Identifier:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        
        // Table setup
        String[] columnNames = {"Staff ID", "Name", "Identifier", "Status", "Location", "Contact", "Assigned Since"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        staffTable = new JTable(tableModel);
        staffTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane tableScrollPane = new JScrollPane(staffTable);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        addButton = new JButton("Add Staff");
        updateButton = new JButton("Update Staff");
        deleteButton = new JButton("Delete Staff");
        refreshButton = new JButton("Refresh");
        
        // Style buttons
        Color buttonColor = new Color(70, 130, 180);
        addButton.setBackground(buttonColor);
        updateButton.setBackground(buttonColor);
        deleteButton.setBackground(buttonColor);
        refreshButton.setBackground(buttonColor);
        searchButton.setBackground(buttonColor);
        
        addButton.setForeground(Color.WHITE);
        updateButton.setForeground(Color.WHITE);
        deleteButton.setForeground(Color.WHITE);
        refreshButton.setForeground(Color.WHITE);
        searchButton.setForeground(Color.WHITE);
        
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        
        // Add components
        add(searchPanel, BorderLayout.NORTH);
        add(tableScrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Event listeners with traditional ActionListener
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showAddStaffDialog();
            }
        });
        
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateSelectedStaff();
            }
        });
        
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteSelectedStaff();
            }
        });
        
        refreshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadStaffData();
            }
        });
        
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                searchStaff();
            }
        });
    }
    
    private void showAddStaffDialog() {
        final JDialog dialog = new JDialog(this, "Add New Staff", true);
        dialog.setLayout(new GridLayout(0, 2, 10, 10));
        dialog.setSize(400, 350);
        dialog.setLocationRelativeTo(this);
        
        final JTextField nameField = new JTextField();
        final JTextField identifierField = new JTextField();
        final JComboBox<String> statusCombo = new JComboBox<String>(new String[]{"Active", "Inactive", "On Leave"});
        final JTextField locationField = new JTextField();
        final JTextField contactField = new JTextField();
        final JTextField assignedSinceField = new JTextField(LocalDate.now().toString());
        
        dialog.add(new JLabel("Name:"));
        dialog.add(nameField);
        dialog.add(new JLabel("Identifier:"));
        dialog.add(identifierField);
        dialog.add(new JLabel("Status:"));
        dialog.add(statusCombo);
        dialog.add(new JLabel("Location:"));
        dialog.add(locationField);
        dialog.add(new JLabel("Contact:"));
        dialog.add(contactField);
        dialog.add(new JLabel("Assigned Since (YYYY-MM-DD):"));
        dialog.add(assignedSinceField);
        
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");
        
        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String name = nameField.getText();
                    String identifier = identifierField.getText();
                    String status = (String) statusCombo.getSelectedItem();
                    String location = locationField.getText();
                    String contact = contactField.getText();
                    LocalDate assignedSince = LocalDate.parse(assignedSinceField.getText());
                    
                    if (addStaffToDatabase(name, identifier, status, location, contact, assignedSince)) {
                        JOptionPane.showMessageDialog(dialog, "Staff added successfully!");
                        dialog.dispose();
                        loadStaffData();
                    } else {
                        JOptionPane.showMessageDialog(dialog, "Failed to add staff!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, 
                        "Please check your input:\n- Date must be in YYYY-MM-DD format", 
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        dialog.add(new JLabel());
        dialog.add(buttonPanel);
        dialog.setVisible(true);
    }
    
    private void updateSelectedStaff() {
        int selectedRow = staffTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a staff member to update");
            return;
        }
        
        final int staffID = (int) tableModel.getValueAt(selectedRow, 0);
        String currentName = tableModel.getValueAt(selectedRow, 1).toString();
        String currentIdentifier = tableModel.getValueAt(selectedRow, 2).toString();
        String currentStatus = tableModel.getValueAt(selectedRow, 3).toString();
        String currentLocation = tableModel.getValueAt(selectedRow, 4).toString();
        String currentContact = tableModel.getValueAt(selectedRow, 5).toString();
        String currentAssignedSince = tableModel.getValueAt(selectedRow, 6).toString();
        
        final JDialog dialog = new JDialog(this, "Update Staff", true);
        dialog.setLayout(new GridLayout(0, 2, 10, 10));
        dialog.setSize(400, 350);
        dialog.setLocationRelativeTo(this);
        
        final JTextField nameField = new JTextField(currentName);
        final JTextField identifierField = new JTextField(currentIdentifier);
        final JComboBox<String> statusCombo = new JComboBox<String>(new String[]{"Active", "Inactive", "On Leave"});
        statusCombo.setSelectedItem(currentStatus);
        final JTextField locationField = new JTextField(currentLocation);
        final JTextField contactField = new JTextField(currentContact);
        final JTextField assignedSinceField = new JTextField(currentAssignedSince);
        
        dialog.add(new JLabel("Name:"));
        dialog.add(nameField);
        dialog.add(new JLabel("Identifier:"));
        dialog.add(identifierField);
        dialog.add(new JLabel("Status:"));
        dialog.add(statusCombo);
        dialog.add(new JLabel("Location:"));
        dialog.add(locationField);
        dialog.add(new JLabel("Contact:"));
        dialog.add(contactField);
        dialog.add(new JLabel("Assigned Since (YYYY-MM-DD):"));
        dialog.add(assignedSinceField);
        
        JButton updateButton = new JButton("Update");
        JButton cancelButton = new JButton("Cancel");
        
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String name = nameField.getText();
                    String identifier = identifierField.getText();
                    String status = (String) statusCombo.getSelectedItem();
                    String location = locationField.getText();
                    String contact = contactField.getText();
                    LocalDate assignedSince = LocalDate.parse(assignedSinceField.getText());
                    
                    if (updateStaffInDatabase(staffID, name, identifier, status, location, contact, assignedSince)) {
                        JOptionPane.showMessageDialog(dialog, "Staff updated successfully!");
                        dialog.dispose();
                        loadStaffData();
                    } else {
                        JOptionPane.showMessageDialog(dialog, "Failed to update staff!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, 
                        "Please check your input:\n- Date must be in YYYY-MM-DD format", 
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(updateButton);
        buttonPanel.add(cancelButton);
        
        dialog.add(new JLabel());
        dialog.add(buttonPanel);
        dialog.setVisible(true);
    }
    
    private void deleteSelectedStaff() {
        int selectedRow = staffTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a staff member to delete");
            return;
        }
        
        final int staffID = (int) tableModel.getValueAt(selectedRow, 0);
        String staffName = tableModel.getValueAt(selectedRow, 1).toString();
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete staff: " + staffName + "?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            if (deleteStaffFromDatabase(staffID)) {
                JOptionPane.showMessageDialog(this, "Staff deleted successfully!");
                loadStaffData();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete staff!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void searchStaff() {
        String searchText = searchField.getText().trim();
        if (searchText.isEmpty()) {
            loadStaffData();
            return;
        }
        
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "SELECT * FROM Staff WHERE Name LIKE ? OR Identifier LIKE ? OR Location LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "%" + searchText + "%");
            stmt.setString(2, "%" + searchText + "%");
            stmt.setString(3, "%" + searchText + "%");
            
            ResultSet rs = stmt.executeQuery();
            tableModel.setRowCount(0);
            
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("StaffID"),
                    rs.getString("Name"),
                    rs.getString("Identifier"),
                    rs.getString("Status"),
                    rs.getString("Location"),
                    rs.getString("Contact"),
                    rs.getDate("AssignedSince").toString()
                };
                tableModel.addRow(row);
            }
            
            rs.close();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error searching staff: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void loadStaffData() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Staff ORDER BY StaffID DESC");
            
            tableModel.setRowCount(0);
            
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("StaffID"),
                    rs.getString("Name"),
                    rs.getString("Identifier"),
                    rs.getString("Status"),
                    rs.getString("Location"),
                    rs.getString("Contact"),
                    rs.getDate("AssignedSince").toString()
                };
                tableModel.addRow(row);
            }
            
            rs.close();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading staff: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Database operations
    private boolean addStaffToDatabase(String name, String identifier, String status, String location, String contact, LocalDate assignedSince) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "INSERT INTO Staff (Name, Identifier, Status, Location, Contact, AssignedSince) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            stmt.setString(1, name);
            stmt.setString(2, identifier);
            stmt.setString(3, status);
            stmt.setString(4, location);
            stmt.setString(5, contact);
            stmt.setDate(6, Date.valueOf(assignedSince));
            
            int rowsAffected = stmt.executeUpdate();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
            return rowsAffected > 0;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    private boolean updateStaffInDatabase(int staffID, String name, String identifier, String status, String location, String contact, LocalDate assignedSince) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "UPDATE Staff SET Name = ?, Identifier = ?, Status = ?, Location = ?, Contact = ?, AssignedSince = ? WHERE StaffID = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            stmt.setString(1, name);
            stmt.setString(2, identifier);
            stmt.setString(3, status);
            stmt.setString(4, location);
            stmt.setString(5, contact);
            stmt.setDate(6, Date.valueOf(assignedSince));
            stmt.setInt(7, staffID);
            
            int rowsAffected = stmt.executeUpdate();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
            return rowsAffected > 0;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    private boolean deleteStaffFromDatabase(int staffID) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "DELETE FROM Staff WHERE StaffID = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            stmt.setInt(1, staffID);
            int rowsAffected = stmt.executeUpdate();
            stmt.close();
            DatabaseConnection.closeConnection(conn);
            
            return rowsAffected > 0;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Staff().setVisible(true);
            }
        });
    }
}